import styled from 'styled-components'

const Form = styled.form`
  width: 100%;
`

export default Form
