# MM Web App
This source code base on Next.JS which is a minimalistic framework for server-rendered React applications.

**Visit https://learnnextjs.com to get started with Next.js.**

## Deployment

* Add produciton repo

 `git remote add azure https://dunghd@maomaoweb.scm.azurewebsites.net:443/maomaoweb.git`

* Add dev repo

`git remote add azure-dev https://dunghd@maomaoweb-dev.scm.azurewebsites.net:443/maomaoweb.git`

We have 2 commands for deploy to Azure server: `yarn deploy:prod` and `yarn deploy:dev`.
