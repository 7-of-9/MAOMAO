console.log('maomao embed js on url', document.baseURI)

// window.addEventListener('unload', function(event) {
//   console.log('maomao embed js - unload', event)
// });

// document.addEventListener("DOMContentLoaded", function(event) {
//   console.log("maomao embed js - DOM fully loaded and parsed",event);
// });

// window.addEventListener("load", function(event) {
//   console.log("maomao embed js - All resources finished loading!");
// });
