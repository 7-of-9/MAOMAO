module.exports = {
  clientCredentials: {
    apiKey: 'AIzaSyBIrR_A8-XugSImY6HCz-GFn6af5YrHJBs',
    authDomain: 'maomao-testing.firebaseapp.com',
    databaseURL: 'https://maomao-testing.firebaseio.com',
    projectId: 'maomao-testing',
    storageBucket: 'maomao-testing.appspot.com',
    messagingSenderId: '323116239222'
  },
  serverCredentials: {
    'type': 'service_account',
    'project_id': 'maomao-testing',
    'private_key_id': '4eb79f5fc501e6374f7baa85e0afa1fd5183acce',
    'private_key': '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDm5DAidKbYbWaT\n2rpUATvbsa7jfnibH+Od0Bzq8xARoblXPIPnoAR5pt2YaIXk268HoHb7UkAQnVBZ\nSWcTmJfAZMazl++6ppSK7SwdXh4X0snONJeAAECHmlBUbbVbi09V+yqy4RsfUL++\noM3vwLVoIFNgcYW3WZFME9xrcVgzS5K+Yh/oGwW55o+J1CA7sqcxgA9Io5A2Ylj2\nuNDmFsvDmD9yIePvMq8zvGNF7POuOwJsUgzEAnXN53xylpZEBm1rwAgUBOS+0Xqe\n2fVURadIKKuAbLlPEVfKXSK14JWnHZgW8vq5VcK/pnrJCxiIPRCSW8bHzXJUVPQS\np5lZFnTbAgMBAAECggEAAMy7ifMDfO5sE4kHajES5wDnjSwr+MWUgUBuSTYMUTNR\nNAcmoc/BFDbKv7Nk+1Tzd0BMCTTQuf4BgD2r2LqHlAgFVCvrjab0DsMhivx/eC+n\nuUofWDcoAhA7xP8YSLfjz3VuQW5cLLCX6W4fKHxvZGvwPf5Gq0rpIO1Urx6WYp8X\ntLRT4dzi8bWVOG2RBBwM5AvMGws5uGOdoRkQfL4593nbeWyJndgf7DfrowLHQCOS\nY6XV2Qb0ooFr+u8wRzPxRFTUteb1iRwCoRzKXVM7N9IvpYSr6lT+hfXhLG4wXWpU\nImfrhRm9UHw/onwHfbscveo9WxGHlivgHsI35Ih5iQKBgQD54ZPlUHx4A9VZhy6a\nsxgpMoO32Mwe03Wn5tBryR6UJTbRg8O/sh9xGh0m0duY9JhUyJPFmfKo8loLqyVc\naXOUVwilvD4uoSU0l0RiIgTtMxGk8pbknUzzLHeZe9sE9sUYtC2a1SqYGOor7ch8\nikZkLAeAXhmJfdMmY2MxIWprTwKBgQDsi5HL24uZcc7AtjMeJUlLI2zyHkUZ2zca\nRCFAHUre3JsAOMk7faYdAh21M1FXb2dwfkYtYYsbR8DE9X1kRFVrYUsSksq6jLR2\nYnV1vozNMfSqaWNwUgKVKUigj1J7tTPKHeqsjiqy2xrnZ3sGRXWTjvL7ojg+4mQn\nMJO+NQCKtQKBgQCi5DwnBnq9ObKAtDDbQ9iCMp3O4RLfHXXbSAmh2e+HH2NG3SBj\n/FemwSEzxyXh5cDPtBkwfRTEsYelh6HJRizEDKBkefwHJaE9UUaQuiCACAR+hG19\nBlW9R8WHVkgGSl9dpUb9YexsTgGJNW62UOVmM5WIRs9a450brzpgMqpO3QKBgBay\nDXsRxYMjeELlOGJcEXw0Ge/hF6AzeEX843PTW6umXvjWefhLRfTijxcjpVpORg51\nDyarhT1I1SYQp8dHBysWWq2dh/X+KhJxv/NcJQZLFL6E/hV4yOam32EIX1GfQSjT\nVgDYYyBmBV7Ofu9LGszdmlKqbdsavaFE9+f4DeVBAoGBAKqBdHzkgZSlF0AE3a9s\nOmpS2PP6FoAijVm3+k+7rsgAyu+RpVRYXfZNUi8djlrl29zmzhURhpBMRGnK5UeC\n0S1BZCiLAEUp682LrddoXX8SH7kCNF0g3rUscuhqhywLkntLR+iZ1dTAySEze2PZ\nDe2DPEynvYITHD9mIRmf2mYf\n-----END PRIVATE KEY-----\n',
    'client_email': 'firebase-adminsdk-az1l3@maomao-testing.iam.gserviceaccount.com',
    'client_id': '105735815106367336717',
    'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
    'token_uri': 'https://accounts.google.com/o/oauth2/token',
    'auth_provider_x509_cert_url': 'https://www.googleapis.com/oauth2/v1/certs',
    'client_x509_cert_url': 'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-az1l3%40maomao-testing.iam.gserviceaccount.com'
  }
}
